import asyncio
import logging
import sys

from aiogram import Bot, Dispatcher, F
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties

from config import BOT_TOKEN, ADMIN_ID
from handlers import start, photo_video, admin

# Configure logging
logging.basicConfig(level=logging.INFO, stream=sys.stdout)

async def main():
    # Initialize Bot and Dispatcher
    bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()

    # Register handlers
    dp.include_router(start.router)
    dp.include_router(photo_video.router)
    dp.include_router(admin.router)

    # Start bot
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
