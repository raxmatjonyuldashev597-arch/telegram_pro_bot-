import sqlite3
from datetime import datetime

class Database:
    def __init__(self, db_file):
        self.connection = sqlite3.connect(db_file)
        self.cursor = self.connection.cursor()
        self.create_tables()

    def create_tables(self):
        with self.connection:
            self.cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    full_name TEXT,
                    phone_number TEXT,
                    referral_id INTEGER,
                    referral_count INTEGER DEFAULT 0,
                    points INTEGER DEFAULT 0,
                    photo_count INTEGER DEFAULT 0,
                    video_count INTEGER DEFAULT 0,
                    joined_date TEXT
                )
            """)

    def add_user(self, user_id, username, full_name, referral_id=None):
        with self.connection:
            joined_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.cursor.execute(
                "INSERT OR IGNORE INTO users (user_id, username, full_name, joined_date, referral_id) VALUES (?, ?, ?, ?, ?)",
                (user_id, username, full_name, joined_date, referral_id)
            )
            # Agar referal orqali kelgan bo'lsa, referal egasiga ball berish
            if referral_id and user_id != referral_id:
                self.cursor.execute(
                    "UPDATE users SET referral_count = referral_count + 1, points = points + 1 WHERE user_id = ?",
                    (referral_id,)
                )

    def update_phone(self, user_id, phone_number):
        with self.connection:
            self.cursor.execute("UPDATE users SET phone_number = ? WHERE user_id = ?", (phone_number, user_id))

    def increment_media_count(self, user_id, media_type, points):
        with self.connection:
            if media_type == "photo":
                self.cursor.execute("UPDATE users SET photo_count = photo_count + 1, points = points + ? WHERE user_id = ?", (points, user_id))
            elif media_type == "video":
                self.cursor.execute("UPDATE users SET video_count = video_count + 1, points = points + ? WHERE user_id = ?", (points, user_id))

    def get_stats(self):
        with self.connection:
            total_users = self.cursor.execute("SELECT COUNT(*) FROM users").fetchone()[0]
            total_photos = self.cursor.execute("SELECT SUM(photo_count) FROM users").fetchone()[0] or 0
            total_videos = self.cursor.execute("SELECT SUM(video_count) FROM users").fetchone()[0] or 0
            return total_users, total_photos, total_videos

    def get_user(self, user_id):
        with self.connection:
            return self.cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)).fetchone()

    def get_all_users(self):
        with self.connection:
            return self.cursor.execute("SELECT user_id, username, full_name FROM users").fetchall()

db = Database("bot_pro_database.db")
