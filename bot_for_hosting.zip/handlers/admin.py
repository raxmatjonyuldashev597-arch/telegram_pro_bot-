from aiogram import Router, types, F
from aiogram.filters import Command
from config import ADMIN_ID
from database import db
from aiogram.exceptions import TelegramForbiddenError

router = Router()

@router.message(Command("stats"), F.from_user.id == ADMIN_ID)
async def stats_cmd(message: types.Message):
    total_users, total_photos, total_videos = db.get_stats()
    await message.answer(
        f"📊 Bot statistikasi:\n\n"
        f"👥 Jami foydalanuvchilar soni: {total_users}\n"
        f"📸 Yuborilgan rasmlar soni: {total_photos}\n"
        f"🎥 Yuborilgan videolar soni: {total_videos}"
    )

@router.message(Command("users"), F.from_user.id == ADMIN_ID)
async def users_cmd(message: types.Message):
    users_list = db.get_all_users()
    if not users_list:
        await message.answer("Foydalanuvchilar hali yo'q.")
        return

    text = "👥 Ro'yxatdan o'tgan foydalanuvchilar:\n\n"
    for user_id, username, full_name in users_list:
        text += f"🆔 {user_id} | @{username} | {full_name}\n"
    
    if len(text) > 4096:
        for x in range(0, len(text), 4096):
            await message.answer(text[x:x+4096])
    else:
        await message.answer(text)

@router.message(Command("broadcast"), F.from_user.id == ADMIN_ID)
async def broadcast_cmd(message: types.Message):
    command_args = message.text.split(maxsplit=1)
    if len(command_args) < 2:
        await message.answer("Xabar matnini kiriting: /broadcast Xabar matni")
        return

    broadcast_text = command_args[1]
    users = db.get_all_users()
    
    count = 0
    failed = 0
    
    status_message = await message.answer(f"Xabar yuborilmoqda... (0/{len(users)})")
    
    for user in users:
        user_id = user[0]
        try:
            await message.bot.send_message(user_id, broadcast_text)
            count += 1
        except TelegramForbiddenError:
            failed += 1
        except Exception:
            failed += 1
        
        if (count + failed) % 10 == 0:
            await status_message.edit_text(f"Xabar yuborilmoqda... ({count + failed}/{len(users)})")

    await status_message.edit_text(
        f"✅ Xabar yuborish yakunlandi!\n\n"
        f"👤 Muvaffaqiyatli: {count}\n"
        f"❌ Muvaffaqiyatsiz: {failed}"
    )
