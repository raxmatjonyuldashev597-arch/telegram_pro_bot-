from aiogram import Router, types, F
from config import CHANNELS, REQUIRED_CHANNEL, POINTS_PER_MEDIA
from database import db
from datetime import datetime
from keyboards import location_keyboard
import pytz

router = Router()

# Vaqtinchalik foydalanuvchi ma'lumotlarini saqlash (media kutayotganda)
user_data = {}

async def is_subscribed(bot, user_id):
    try:
        member = await bot.get_chat_member(chat_id=REQUIRED_CHANNEL, user_id=user_id)
        if member.status in ["member", "administrator", "creator"]:
            return True
        return False
    except:
        return False

@router.message(F.contact)
async def contact_handler(message: types.Message):
    user_id = message.from_user.id
    phone_number = message.contact.phone_number
    db.update_phone(user_id, phone_number)
    await message.answer(
        "Rahmat! ✅\n"
        "Endi rasm yoki video yuboring.",
        reply_markup=types.ReplyKeyboardRemove()
    )

@router.message(F.photo | F.video)
async def media_handler(message: types.Message):
    user_id = message.from_user.id
    user = db.get_user(user_id)
    
    # Telefon raqam va obunani tekshirish
    if not await is_subscribed(message.bot, user_id):
        from keyboards import check_subscription_keyboard
        await message.answer("Botdan foydalanish uchun avval kanalga obuna bo'ling", reply_markup=check_subscription_keyboard())
        return
    
    if not user[3]: # Telefon raqam yo'q bo'lsa
        from keyboards import contact_keyboard
        await message.answer("Avval telefon raqamingizni yuboring:", reply_markup=contact_keyboard())
        return

    # Media ma'lumotlarini saqlash
    media_id = message.photo[-1].file_id if message.photo else message.video.file_id
    media_type = "photo" if message.photo else "video"
    
    user_data[user_id] = {
        "media_id": media_id,
        "media_type": media_type
    }
    
    await message.answer(
        "Media qabul qilindi! ✅\n"
        "Endi joylashuvingizni yuboring:",
        reply_markup=location_keyboard()
    )

@router.message(F.location)
async def location_handler(message: types.Message):
    user_id = message.from_user.id
    if user_id not in user_data:
        await message.answer("Avval rasm yoki video yuboring!")
        return

    media_info = user_data.pop(user_id)
    user = db.get_user(user_id)
    
    uz_tz = pytz.timezone('Asia/Tashkent')
    now = datetime.now(uz_tz).strftime("%Y-%m-%d %H:%M:%S")
    
    location = f"https://www.google.com/maps?q={message.location.latitude},{message.location.longitude}"
    
    caption = (
        f"📩 Yangi xabar!\n\n"
        f"👤 Foydalanuvchi ID: {user_id}\n"
        f"🔗 Username: @{user[1]}\n"
        f"📝 Ismi: {user[2]}\n"
        f"📞 Tel: {user[3]}\n"
        f"📍 Joylashuv: {location}\n"
        f"📅 Sana va vaqt: {now}"
    )

    # Kanallarga yuborish
    for channel in CHANNELS:
        try:
            if media_info["media_type"] == "photo":
                await message.bot.send_photo(channel, media_info["media_id"], caption=caption)
            else:
                await message.bot.send_video(channel, media_info["media_id"], caption=caption)
        except Exception as e:
            print(f"Xatolik: {e}")

    # Ballarni yangilash
    db.increment_media_count(user_id, media_info["media_type"], POINTS_PER_MEDIA)
    
    await message.answer(
        f"Ma'lumotlar kanallarga yuborildi! ✅\n"
        f"Sizga {POINTS_PER_MEDIA} ball qo'shildi.",
        reply_markup=types.ReplyKeyboardRemove()
    )
