from aiogram import Router, types, F
from aiogram.filters import CommandStart, CommandObject
from config import REQUIRED_CHANNEL, ADMIN_ID
from database import db
from keyboards import check_subscription_keyboard, contact_keyboard

router = Router()

async def is_subscribed(bot, user_id):
    try:
        member = await bot.get_chat_member(chat_id=REQUIRED_CHANNEL, user_id=user_id)
        if member.status in ["member", "administrator", "creator"]:
            return True
        return False
    except:
        return False

@router.message(CommandStart())
async def start_cmd(message: types.Message, command: CommandObject):
    user_id = message.from_user.id
    username = message.from_user.username or "Noma'lum"
    full_name = message.from_user.full_name

    # Referal ID ni tekshirish
    referral_id = None
    if command.args and command.args.isdigit():
        referral_id = int(command.args)

    # Foydalanuvchini bazaga qo'shish
    db.add_user(user_id, username, full_name, referral_id)

    # Obunani tekshirish
    if await is_subscribed(message.bot, user_id):
        user = db.get_user(user_id)
        if not user[3]: # Telefon raqam yo'q bo'lsa
            await message.answer(
                f"Xush kelibsiz, {full_name}! 👋\n"
                f"Botdan foydalanish uchun telefon raqamingizni yuboring:",
                reply_markup=contact_keyboard()
            )
        else:
            await message.answer(
                f"Xush kelibsiz, {full_name}! 👋\n"
                f"Iltimos, rasm yoki video yuboring."
            )
    else:
        await message.answer(
            "Botdan foydalanish uchun avval kanalga obuna bo'ling",
            reply_markup=check_subscription_keyboard()
        )

@router.callback_query(F.data == "check_sub")
async def check_subscription(callback: types.CallbackQuery):
    if await is_subscribed(callback.bot, callback.from_user.id):
        await callback.message.delete()
        user = db.get_user(callback.from_user.id)
        if not user[3]: # Telefon raqam yo'q bo'lsa
            await callback.message.answer(
                "Obuna tasdiqlandi! ✅\n"
                "Endi telefon raqamingizni yuboring:",
                reply_markup=contact_keyboard()
            )
        else:
            await callback.message.answer(
                "Obuna tasdiqlandi! ✅\n"
                "Iltimos, rasm yoki video yuboring."
            )
    else:
        await callback.answer("Siz hali ham obuna bo'lmagansiz! ❌", show_alert=True)
