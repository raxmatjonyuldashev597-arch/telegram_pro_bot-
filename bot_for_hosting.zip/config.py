import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = "8752421811:AAHY6wK0CE_ZwDIiFdIX73M5Yjj-255u7ro"
ADMIN_ID = 123456789  # Sizning ID raqamingiz

CHANNELS = [
    "@foydalee098",
    "@asilbek_mamurov08"
]

REQUIRED_CHANNEL = "@foydalee098"
REQUIRED_CHANNEL_URL = "https://t.me/foydalee098"

# Ballar tizimi
POINTS_PER_REFERRAL = 1
POINTS_PER_MEDIA = 2
